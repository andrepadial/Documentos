﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIX_GI_AtualizacaoVersao.Entities
{
    public class HistoricoVersaoAutbank
    {
        public int Id { get; set; }
        public string VersaoAutbank { get; set; }
        public string API { get; set; }
        public string VersaoAPI { get; set; }
        public string Arquivo { get; set; }


    }
}
