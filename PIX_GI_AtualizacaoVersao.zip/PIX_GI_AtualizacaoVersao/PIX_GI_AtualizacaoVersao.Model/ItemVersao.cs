﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIX_GI_AtualizacaoVersao.Model
{
    public class ItemVersao
    {
        public string API { get; set; }
        public string VersaoAPI { get; set; }
        public string Arquivo { get; set; }

    }
}
