USE AB_DDAMSG
go

/*
  $Id: SP_GRAVA_CORPO_TRANS_INT
	2001/12/17 15:00:00 MICHELLE - FOI COLOCADO O PARAMETRO @SEQXML NA DECLARACAO DA PROC

  Autbank Projetos e Consultoria Ltda.

*/
IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_GRAVA_CORPO_TRANS_INTF')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_GRAVA_CORPO_TRANS_INTF  AS BEGIN RETURN END'  
END
go

ALTER proc SP_GRAVA_CORPO_TRANS_INTF (
   @CODSISTEMA_O char(10),
   @NUMORIGEM    char(20),
   @DESTINO      char(10),
   @XML          varchar(255),
   @SEQXML       int
)
as

begin
   DECLARE @SQLERRO INT

   insert into CORPO_TRANS_INTERF
      (CODSISTEMA_O,
       NUMORIGEM,
       DESTINO,
       SEQXML,
       XML)
   values
      (@CODSISTEMA_O,
       @NUMORIGEM,
       @DESTINO,
       @SEQXML,
       @XML)  

   SELECT @SQLERRO = @@ERROR
   IF @SQLERRO <> 0
      GOTO TRATAERRO

   RETURN (0)

TRATAERRO:
   RETURN (@SQLERRO)
end
go

/*
  $Id$
  Autbank Projetos e Consultoria Ltda.
*/
IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_GRAVA_CORPO_TRANS_USERMSG')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_GRAVA_CORPO_TRANS_USERMSG  AS BEGIN RETURN END'  
END
go

ALTER proc SP_GRAVA_CORPO_TRANS_USERMSG (
   @CODSISTEMA_O char(10),
   @NUMORIGEM    char(20),
   @DESTINO      char(10),
   @XML          text
)
as
begin
   DECLARE @SQLERRO INT

   insert into CORPO_TRANS_INTERF_USMSG
      (CODSISTEMA_O,
       NUMORIGEM,
       DESTINO,
       XML)
   values
      (@CODSISTEMA_O,
       @NUMORIGEM,
       @DESTINO,
       @XML)  
   
   SELECT @SQLERRO = @@ERROR
   IF @SQLERRO <> 0
      GOTO TRATAERRO

   RETURN (0)

TRATAERRO:
   RETURN (@SQLERRO)

end
go


/*
  $Id$
  Autbank Projetos e Consultoria Ltda.
  17/05/2004 - Carlos - Incluiu parametro @TEMTRANSACAO
  07/03/2005 - Carlos - Incluiu parametro @MODULO
  18/04/2005 - Edu - Incluiu parametro @CODINST
  29/09/2005 - Edu - Incluiu parametro @SUBSISORIGEM
  26/04/2007 - Carlos - Incluiu parametro @NUMCTRLIFOR
  25/04/2008 - Carlos - Incluiu parametro @STATUSOP
  14/11/2012 - Carlos - Inclui parametros @ASSINATURATED, @USUARIOASSINATURA
  05/02/2015 - Carlos - Alterado para gravar S em STATUSINTF somente apos gravar a mensagem XML
*/
IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_GRAVA_TRANS_INTF')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_GRAVA_TRANS_INTF  AS BEGIN RETURN END'  
END
go

ALTER PROC dbo.SP_GRAVA_TRANS_INTF (
   @CODSISTEMA_O char(10),
   @NUMORIGEM    char(20),
   @AUTORIZADO   char(01),
   @DATARESERVA  datetime,
   @DTHRVENCTO   datetime,
   @NROBOLETO    char(20),
   @DESTINO      char(10),
   @USUARIO      char(30),
   @XML          text,
   @XMLUSR       text,
   @NROBORDERO   varchar(07) = null,
   @TEMTRANSACAO CHAR(01),
   @MODULO       CHAR(03),
   @CODINST      CHAR(08),
   @ERRO         varchar(50) output,
   @SUBSISTEMA_O varchar(10) = NULL,
   @NUMCTRLIFOR  varchar(20) = NULL,
   @STATUSOP     char(1) = NULL,
   @ASSINATURATED varbinary(128) = NULL,
   @USUARIOASSINATURA char(20) = NULL
)
as
begin
   declare @SQLERROR int,
           @DATARESERVAP datetime,
           @STATUSSGR CHAR(1), @I INT, @J INT, @XML1 VARCHAR(255)

   IF @TEMTRANSACAO = 'S'
      BEGIN TRANSACTION

   select @ERRO = '',
          @DATARESERVAP = convert(datetime,convert(char(10),@DATARESERVA,101))

   IF @AUTORIZADO <> '1' AND @AUTORIZADO <> '2' AND @AUTORIZADO <> '3' 
      BEGIN   	
   	   IF @AUTORIZADO = 'S'
            SELECT @STATUSSGR = '2'
   	   ELSE
      	SELECT @STATUSSGR = '1'
	END
   ELSE
	SELECT @STATUSSGR = @AUTORIZADO

   SELECT @DESTINO = @CODSISTEMA_O

   insert into TRANS_INTERF
      (CODSISTEMA_O,
       NUMORIGEM,
       NUMORIGEMOR,
       DESTINO,
       STATUSSGR,
       SITUACAO,
       DATARESERVA,
       DTHRVENCTO,
       DTHRINC,
       USUARIOINC,
       STATUSINTF,
       NROBOLETO,
	 NROBORDERO,
       MODULO,
	 CODINST,
       SUBSISTEMA_O,
       NUMCTRLIFOR,
       STATUSOP)
   values
      (@CODSISTEMA_O,
       @NUMORIGEM,
       @NUMORIGEM,
       @DESTINO,
       @STATUSSGR,
       'A',
       @DATARESERVAP,
       @DTHRVENCTO,
       getdate(),
       @USUARIO,
       'X',
       @NROBOLETO,
       @NROBORDERO,
       @MODULO,
       @CODINST,
       @SUBSISTEMA_O,
       @NUMCTRLIFOR,
       @STATUSOP)

   select @SQLERROR = @@error
   if @SQLERROR != 0
      begin
         IF @TEMTRANSACAO = 'S'
            ROLLBACK TRANSACTION
         select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela TRANS_INTERF' 
         return(1)
      end

   if @USUARIOASSINATURA IS NOT NULL AND RTRIM(@USUARIOASSINATURA) <> ''
	  begin
	  
		  insert into ASSN_TRANS_INTERF
			(CODSISTEMA_O,      
			NUMORIGEM,          
			DESTINO,           
			ID,                  
			ASSINATURA)
		  values
			(@CODSISTEMA_O,
			@NUMORIGEM,
			@DESTINO,
			@USUARIOASSINATURA , 
			@ASSINATURATED)   
       
		  select @SQLERROR = @@error
		  if @SQLERROR != 0
			begin
				IF @TEMTRANSACAO = 'S'
					ROLLBACK TRANSACTION
				select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela  ASSN_TRANS_INTERF' 
				return(1)
			end 	 
	  
	  end		
       
   select @SQLERROR = @@error
   if @SQLERROR != 0
      begin
         IF @TEMTRANSACAO = 'S'
            ROLLBACK TRANSACTION
         select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela  ASSN_TRANS_INTERF' 
         return(1)
      end 	 
   
   SELECT @I = 1, @J = 1
   WHILE @I <= DATALENGTH(@XML)
      BEGIN
      SELECT @XML1 = SUBSTRING(@XML, @I, 255)
      EXEC @SQLERROR = SP_GRAVA_CORPO_TRANS_INTF @CODSISTEMA_O, @NUMORIGEM, @DESTINO, @XML1, @J
      IF @SQLERROR <> 0
         GOTO TRATAERRO
      SELECT @I = @I + 255, @J = @J + 1
      END

   IF DATALENGTH(@XMLUSR) > 0  
	BEGIN
         EXEC @SQLERROR = SP_GRAVA_CORPO_TRANS_USERMSG @CODSISTEMA_O, @NUMORIGEM, @DESTINO, @XMLUSR
         IF @SQLERROR <> 0
           GOTO TRATAERRO_USR
	END	

   UPDATE TRANS_INTERF SET STATUSINTF = 'S'
    WHERE CODSISTEMA_O = @CODSISTEMA_O AND NUMORIGEM = @NUMORIGEM AND DESTINO = @DESTINO

   IF @TEMTRANSACAO = 'S'
      COMMIT TRANSACTION
   return(0)

TRATAERRO:
   IF @TEMTRANSACAO = 'S'
      ROLLBACK TRANSACTION
   select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela CORPO_TRANS_INTERF' 
   return(1)

TRATAERRO_USR:
   IF @TEMTRANSACAO = 'S'
      ROLLBACK TRANSACTION
   select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela CORPO_TRANS_INTERF_USMSG' 
   return(1)

end
go


/*
  $Id$
  Autbank Projetos e Consultoria Ltda.
  17/05/2004 - Carlos - Incluiu parametro @TEMTRANSACAO
  07/03/2005 - Carlos - Incluiu parametro @MODULO
*/

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_GRAVA_ERRO_INTF')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_GRAVA_ERRO_INTF  AS BEGIN RETURN END'  
END
go

ALTER PROC dbo.SP_GRAVA_ERRO_INTF (
   @CODSISTEMA_O char(10),
   @NUMORIGEM    char(20),
   @TIPO_INTRF   char(3),
   @AUTORIZADO   char(01),
   @DATARESERVA  varchar(10),
   @DTHRVENCTO   varchar(16),
   @NROBOLETO    char(20),
   @DESTINO      char(10),
   @USUARIO      char(30),
   @FORMATOMSG   char(1),
   @DATAMOVTO    varchar(10),
   @CODERRO      int,
   @DESCERRO     varchar(255),
   @XML          text,
   @TEMTRANSACAO CHAR(01),
   @MODULO       CHAR(03),
   @ERRO         varchar(50) output
)
as
begin
   declare @SQLERROR int,
           @STATUSSGR CHAR(1), @I INT, @J INT, @XML1 VARCHAR(255),
           @DATAPROCES datetime, @SEQUENCIAL INT

   IF @TEMTRANSACAO = 'S'
      BEGIN TRANSACTION

   SELECT @ERRO = ''

   SELECT @DATAPROCES = DATAPROCES FROM PARAMETROS

   SELECT @SEQUENCIAL = MAX(SEQUENCIAL) FROM ERROS_INTERF
    WHERE DATAPROCES = @DATAPROCES AND CODSISTEMA_O = @CODSISTEMA_O
      AND NUMORIGEM = @NUMORIGEM

   IF @SEQUENCIAL IS NULL
      SELECT @SEQUENCIAL = 1
   ELSE
      SELECT @SEQUENCIAL = @SEQUENCIAL + 1

   insert into ERROS_INTERF
      (DATAPROCES,
       CODSISTEMA_O,
       NUMORIGEM,
       SEQUENCIAL,
       TIPO_INTRF,
       AUTORIZADO,
       DATARESERVA,
       DTHRVENCTO,
       DATAMOVTO,
       NROBOLETO,
       CODSISTEMA_D,
       FORMATOMSG,
       USUARIO,
       CODERRO,
       MOTIVOREJEI,
       DTHRINC,
       MODULO)
   values
      (@DATAPROCES,
       @CODSISTEMA_O,
       @NUMORIGEM,
       @SEQUENCIAL,
       @TIPO_INTRF,
       @AUTORIZADO,
       @DATARESERVA,
       @DTHRVENCTO,
       @DATAMOVTO,
       @NROBOLETO,
       @DESTINO,
       @FORMATOMSG,
       @USUARIO,
       @CODERRO,
       @DESCERRO,
       getdate(),
       @MODULO)

   select @SQLERROR = @@error
   if @SQLERROR != 0
      begin
         IF @TEMTRANSACAO = 'S'
            ROLLBACK TRANSACTION
         select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela TRANS_INTERF' 
         return(1)
      end

   SELECT @I = 1, @J = 1
   WHILE @I <= DATALENGTH(@XML)
      BEGIN
      SELECT @XML1 = SUBSTRING(@XML, @I, 255)

      insert into CORPO_ERROS_INTERF
         (DATAPROCES,
          CODSISTEMA_O,
          NUMORIGEM,
          SEQUENCIAL,
          SEQXML,
          XML)
      values
         (@DATAPROCES,
          @CODSISTEMA_O,
          @NUMORIGEM,
          @SEQUENCIAL,
          @J,
          @XML1)

      SELECT @SQLERROR = @@ERROR
      IF @SQLERROR <> 0
         GOTO TRATAERRO
      SELECT @I = @I + 255, @J = @J + 1
      END

   IF @TEMTRANSACAO = 'S'
      COMMIT TRANSACTION
   return(0)

TRATAERRO:
   IF @TEMTRANSACAO = 'S'
      ROLLBACK TRANSACTION
   select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela CORPO_ERRO_INTERF' 
   return(1)

end
go

/*
  $Id: SP_GRAVA_CORPO_PREV
      Autor: Eduardo Foresti 10/05/2004
      Autbank Projetos e Consultoria Ltda. 
*/

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_GRAVA_CORPO_PREV')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_GRAVA_CORPO_PREV  AS BEGIN RETURN END'  
END
go

ALTER proc SP_GRAVA_CORPO_PREV (
   @CODSISTEMA_O char(10),
   @CODINST      char(8),
   @NUMORIGEM    char(20),
   @XML          varchar(255),
   @SEQXML       int
)
as

begin
   DECLARE @SQLERRO INT

   insert into CORPO_PREV
      (CODSISTEMA_O,
       CODINST,
       NUMORIGEM,
       SEQXML,
       XML)
   values
      (@CODSISTEMA_O,
       @CODINST,
       @NUMORIGEM,
       @SEQXML,
       @XML)  

   SELECT @SQLERRO = @@ERROR
   IF @SQLERRO <> 0
      GOTO TRATAERRO

   RETURN (0)

TRATAERRO:
   RETURN (@SQLERRO)
end
go


/*
  $Id$
  Autbank Projetos e Consultoria Ltda.

  	Procedure SP_INCLUI_PREVISAO
	Data Criacao : 02/07/2001
	Autora : Alessandra Marques
	Descricao : Inclusao de dados na tabela PREVISOES. 
      Alteracoes: 12/09/2001  Retirou o calculo e gravacao do NUMCTRLIF
                  08/04/2004  Inclus�o do campo Nome do Cliente 
                  10/05/2004  Inclus�o do campo Xml
                  17/05/2004 - Incluiu parametro @TEMTRANSACAO
*/

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_INCLUI_PREVISAO')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_INCLUI_PREVISAO  AS BEGIN RETURN END'  
END
go

ALTER PROC dbo.SP_INCLUI_PREVISAO (   
	@CODINST	char(8),
	@NUMORIGEM	char(20),
	@NROBOLETO	char(20),
	@CODSISTEMA_O	char(10),
	@DATARESERVA	datetime,
	@VALOR		numeric(17,2),
	@NATUREZA	char(1),                 
	@ISPBCONPAR		char(8),
	@AGENCIA	char(4),
	@NROCONTA	varchar(13),
	@CNPJ_CPF	varchar(14),	
	@ISPBCAM		varchar(8),
	@DESCRICAO	varchar(50),
	@TIPO_LIQ	char(03),
	@USUARIOINC	varchar(30),
      @NOMECLI     varchar(35) = null,
      @XML        text = null,
      @TEMTRANSACAO CHAR(01),
	@ERRO		varchar(50) output
)
as begin
	declare @SQLERROR int,
		@DATARESERVAP datetime,
		@DATAMOVTOP datetime, 
		@SQLCOUNT int,@I INT, @J INT, @XML1 VARCHAR(255)

      IF @TEMTRANSACAO = 'S'
         BEGIN TRANSACTION

  	select  @ERRO = '',
		@DATARESERVAP = convert(datetime,(convert(char(10),@DATARESERVA,101) + ' ' + convert(char(5),@DATARESERVA,108)))

	select @DATAMOVTOP = convert(datetime,convert(varchar,DATAPROCES,101))
        from PARAMETROS	

	/* Verifica Nro Boleto*/
      IF @NROBOLETO is null OR @NROBOLETO = ''
         SELECT @NROBOLETO = @NUMORIGEM

	/* Verifica se o tipo de natureza e valido*/
	if (@NATUREZA <> 'C' and @NATUREZA <> 'D')
    	begin
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'Tipo de natureza invalido'
		goto trata_erro
	end	

	/* Verifica se o valor da previsao e maior que zero*/
	if (@VALOR <= 0)
    	begin
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'O valor da previsao deve ser maior que zero'
		goto trata_erro
	end	
	
	/* Verifica se o codigo da instituicao logada e valido*/
	IF NOT EXISTS(select CODINST from EMPRESAS where CODINST = @CODINST)
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Codigo da instituicao logada nao cadastrado'
         goto trata_erro
         END
	
	/* Verifica se o codigo da instituicao da contraparte e valido*/
      IF RTRIM(@ISPBCONPAR) <> ''
         BEGIN
         IF NOT EXISTS(select CODINST From INSTITUICOES where CODINST = @ISPBCONPAR)
            BEGIN
            SELECT @SQLERROR = @@error + 30000
            SELECT @ERRO = 'ISPB da instituicao financeira - contraparte, nao cadastrado'
            goto trata_erro
            END
         END
	
	/*Caso se tenha digitado o codigo da instituicao da contraparte e a agencia , verifica
	se o cogido da agencia digitado pertence � instituicao*/
	IF (RTRIM(@ISPBCONPAR) <> '' and RTRIM(@AGENCIA) <> '')
         BEGIN
         IF NOT EXISTS(select CODAGENCIA from AGENCIAS
                        where CODINST = @ISPBCONPAR and CODAGENCIA = @AGENCIA)
            BEGIN
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'Codigo da agencia invalido'
		goto trata_erro
		END 
         END
		
	/* Liquidacao CMP, somar um dia em @DATARESERVA */
	IF @TIPO_LIQ = 'CMP'
         SELECT @DATARESERVA = DATEADD(day, 1, @DATARESERVA)

    	insert into PREVISOES
	(
		CODINST,
		NUMORIGEM,
		NROBOLETO,
		CODSISTEMA_O,
		DATAMOVTO,
		DATARESERVA,
		VALORMOVTO,
            VALORORIGN,
		NATUREZA,                 
		SITUACAO,
		ISPBCONPAR,
		AGENCIA,
		NROCONTA,
		CNPJ_CPF,	
		ISPBCAM,
		DESCRICAO,
            TIPO_LIQ,
            VALOREFETV,
            USUARIOINC,
            USUARIO,
            DATAATU,
            NOMECLI
	)
	values
	(
		@CODINST,
		@NUMORIGEM,
		@NROBOLETO,
		@CODSISTEMA_O,
		@DATAMOVTOP,
		@DATARESERVAP,
		@VALOR,
		@VALOR,
		@NATUREZA,                 
		'A',
		@ISPBCONPAR,
		@AGENCIA,
		@NROCONTA,
		@CNPJ_CPF,	
		@ISPBCAM,
		@DESCRICAO,
            @TIPO_LIQ,
            0,
            @USUARIOINC,
            @USUARIOINC,
            GETDATE(),
		@NOMECLI
	)

   select @SQLERROR = @@error
   if @SQLERROR != 0
      begin
         IF @TEMTRANSACAO = 'S'
            ROLLBACK TRANSACTION
         select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela PREVISOES' 
         return(1)
      end

     IF @XML IS NOT NULL
     BEGIN	 
	     SELECT @I = 1, @J = 1
           WHILE @I <= DATALENGTH(@XML)
        	  BEGIN
	        SELECT @XML1 = SUBSTRING(@XML, @I, 255)
      	  EXEC @SQLERROR = SP_GRAVA_CORPO_PREV @CODSISTEMA_O, @CODINST,@NUMORIGEM, @XML1, @J
	        IF @SQLERROR <> 0
      	     GOTO trata_erro
	        SELECT @I = @I + 255, @J = @J + 1
	        END
      END

   IF @TEMTRANSACAO = 'S'
      COMMIT TRANSACTION
   return(0)

/* rotina de erro    */
trata_erro:
      IF @TEMTRANSACAO = 'S'
         ROLLBACK TRANSACTION
 	IF (@SQLERROR > 30000)
  	BEGIN
		SELECT @ERRO = @ERRO + ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na insercao da tabela PREVISOES'
		return(1)
	END
end
go


/*
  $Id$
  Autbank Projetos e Consultoria Ltda.

  	Procedure SP_ALTERA_PREVISAO
	Data Criacao : 14/09/2001
	Autora : Carlos Augusto
	Descricao : Alteracao de dados na tabela PREVISOES. 
      Manutencoes: 24/01/2002 - Tratamento p/ VALOR = 0 qdo TIPO_ALT = 0
                   17/05/2004 - Incluiu parametro @TEMTRANSACAO
		   03/01/2007 - Incluiu parametro @MSGXML
		   05/02/2015 - Carlos - Atualizar campo STATUSMIP com NULL nas atualizacoes da tabela PREVISOES
		   08/11/2017 - Carlos - Retirado tratamento para coluna STATUSMIP
*/

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_ALTERA_PREVISAO')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_ALTERA_PREVISAO  AS BEGIN RETURN END'  
END
go

ALTER PROC dbo.SP_ALTERA_PREVISAO (   
	@CODINST	char(8),
	@CODSISTEMA_O	char(10),
	@NUMORIGEM	char(20),
	@NROBOLETO	char(20),
	@DATARESERVA	varchar(16),
	@VALOR		numeric(17,2),
	@NATUREZA	char(1),                 
	@ISPBCONPAR		char(8),
	@AGENCIA	char(4),
	@NROCONTA	varchar(13),
	@CNPJ_CPF	varchar(14),	
	@ISPBCAM	char(8),
	@DESCRICAO	varchar(50),
	@TIPO_LIQ	char(03),
	@USUARIO	varchar(30),
	@TIPO_ALT	smallint,
        @TEMTRANSACAO   CHAR(01),
	@ERRO		varchar(50) output,
	@MSGXML         text = null
)
as begin
	declare @SQLERROR int, @DATARESERVAP datetime, @FORNEC VARCHAR(10),
              @VALORMOVTO numeric(17,2), @VALORORIGN numeric(17,2),
	      @I INT, @J INT, @XML1 VARCHAR(255)

      IF @TEMTRANSACAO = 'S'
         BEGIN TRANSACTION

  	select  @ERRO = ''

	/* Verifica se o codigo da instituicao logada e valido*/
	IF NOT EXISTS(select CODINST from EMPRESAS where CODINST = @CODINST)
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Codigo da instituicao logada nao cadastrado'
         goto trata_erro
         END
	
      IF NOT EXISTS(SELECT * FROM PREVISOES 
                     WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
                       AND NUMORIGEM = @NUMORIGEM)
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Previsao nao cadastrada.'
         goto trata_erro
         END

      IF EXISTS(SELECT * FROM PREVISOES 
                 WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
                   AND NUMORIGEM = @NUMORIGEM AND SITUACAO = 'C')
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Previsao cancelada, alteracao nao permitida.'
         goto trata_erro
         END
      
      /* Recupera Valor do Movimento e o Valor Original da Previsao*/
      SELECT @VALORMOVTO = VALORMOVTO,@VALORORIGN = VALORORIGN
        FROM PREVISOES
       WHERE CODINST = @CODINST AND
             CODSISTEMA_O = @CODSISTEMA_O AND
             NUMORIGEM = @NUMORIGEM

      if @DATARESERVA <> '-'
	   SELECT @DATARESERVAP = convert(datetime,convert(char(10),@DATARESERVA,101))

	/* Verifica se o tipo de natureza e valido*/
      IF @NATUREZA <> '-'
         BEGIN
         if (@NATUREZA <> 'C' and @NATUREZA <> 'D')
            begin
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'Tipo de natureza invalido'
		goto trata_erro
            end	
         END

	/* Verifica valor da previsao */
	if (@VALOR < 0)
    	begin
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'O valor da previsao deve ser maior que zero'
		goto trata_erro
	end	
	
	/* Verifica se o codigo da instituicao da contraparte e valido*/
      IF @ISPBCONPAR <> '-'
         BEGIN
         IF RTRIM(@ISPBCONPAR) <> ''
            BEGIN
            IF NOT EXISTS(select CODINST From INSTITUICOES where CODINST = @ISPBCONPAR)
               BEGIN
               SELECT @SQLERROR = @@error + 30000
               SELECT @ERRO = 'ISPB da instituicao financeira - contraparte, nao cadastrado'
               goto trata_erro
               END
            END
         END
	
	/*Caso se tenha digitado o codigo da instituicao da contraparte e a agencia , verifica
	se o cogido da agencia digitado pertence � instituicao*/
      IF @ISPBCONPAR <> '-' AND @AGENCIA <> '-'
         BEGIN
         IF (RTRIM(@ISPBCONPAR) <> '' and RTRIM(@AGENCIA) <> '')
            BEGIN
            IF NOT EXISTS(select CODAGENCIA from AGENCIAS
                           where CODINST = @ISPBCONPAR and CODAGENCIA = @AGENCIA)
               BEGIN
	         SELECT @SQLERROR = @@error + 30000
               SELECT @ERRO = 'Codigo da agencia invalido'
               goto trata_erro
               END 
            END
         END
		
      /* Verifica fornecedor */
      SELECT @FORNEC = RTRIM(FORNECEDOR) FROM SISTEMASINT
       WHERE CODSISTEMA = @CODSISTEMA_O

      /* Permite alterar todas as informacoes */
      IF @TIPO_ALT = 0
         BEGIN

	   IF @NROBOLETO <> '-'
            BEGIN
            UPDATE PREVISOES SET NROBOLETO = @NROBOLETO, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @DATARESERVA <> '-'
            BEGIN
            UPDATE PREVISOES SET DATARESERVA = @DATARESERVAP, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF (@VALOR >= 0 AND @FORNEC = 'CRK') OR (@VALOR >= 0 AND @VALORMOVTO = @VALORORIGN)
            BEGIN
            UPDATE PREVISOES SET VALORMOVTO = @VALOR, VALORORIGN = @VALOR, 
                                 USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @NATUREZA <> '-'
            BEGIN
            UPDATE PREVISOES SET NATUREZA = @NATUREZA, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @ISPBCONPAR <> '-'
            BEGIN
            UPDATE PREVISOES SET ISPBCONPAR = @ISPBCONPAR, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @AGENCIA <> '-'
            BEGIN
            UPDATE PREVISOES SET AGENCIA = @AGENCIA, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @NROCONTA <> '-'
            BEGIN
            UPDATE PREVISOES SET NROCONTA = @NROCONTA, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @CNPJ_CPF <> '-'
            BEGIN
            UPDATE PREVISOES SET CNPJ_CPF = @CNPJ_CPF, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @ISPBCAM <> '-'
            BEGIN
            UPDATE PREVISOES SET ISPBCAM = @ISPBCAM, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @DESCRICAO <> '-'
            BEGIN
            UPDATE PREVISOES SET DESCRICAO = @DESCRICAO, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	   IF @TIPO_LIQ <> '-'
            BEGIN
            UPDATE PREVISOES SET TIPO_LIQ = @TIPO_LIQ, USUARIO = @USUARIO, DATAATU = GETDATE()
             WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
               AND NUMORIGEM = @NUMORIGEM

            SELECT @SQLERROR = @@error + 30000
            IF (@SQLERROR > 30000) 
               BEGIN
               SELECT @ERRO = 'Erro na alteracao da previsao'
               goto trata_erro
               END 
            END

	    IF DATALENGTH(@MSGXML) > 0 
               BEGIN
	          DELETE CORPO_PREV
		  WHERE CODINST = @CODINST
		  AND CODSISTEMA_O = @CODSISTEMA_O
		  AND NUMORIGEM = @NUMORIGEM

	          SELECT @I = 1, @J = 1
                  WHILE @I <= DATALENGTH(@MSGXML)
        	     BEGIN
	                SELECT @XML1 = SUBSTRING(@MSGXML, @I, 255)
      	                EXEC @SQLERROR = SP_GRAVA_CORPO_PREV @CODSISTEMA_O, @CODINST,@NUMORIGEM, @XML1, @J
	                IF @SQLERROR <> 0
      	                   GOTO trata_erro
	                SELECT @I = @I + 255, @J = @J + 1
	             END

	       END
         END

      /* Soma no Valor da Previsao */
      IF @TIPO_ALT = 1
         BEGIN
         UPDATE PREVISOES SET VALORMOVTO = VALORMOVTO + @VALOR,
                              USUARIO = @USUARIO, DATAATU = GETDATE()
          WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
            AND NUMORIGEM = @NUMORIGEM

         SELECT @SQLERROR = @@error + 30000
         IF (@SQLERROR > 30000) 
            BEGIN
            SELECT @ERRO = 'Erro na alteracao da previsao'
            goto trata_erro
            END 
         END

      /* Subtrai do Valor da Previsao */
      IF @TIPO_ALT = 2
         BEGIN
         UPDATE PREVISOES SET VALORMOVTO = VALORMOVTO - @VALOR,
                              USUARIO = @USUARIO, DATAATU = GETDATE()
          WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
            AND NUMORIGEM = @NUMORIGEM

         SELECT @SQLERROR = @@error + 30000
         IF (@SQLERROR > 30000) 
            BEGIN
            SELECT @ERRO = 'Erro na alteracao da previsao'
            goto trata_erro
            END 
         END

      /* Soma no Valor de Previsoes Efetivadas */
      IF @TIPO_ALT = 3
         BEGIN
         UPDATE PREVISOES SET VALOREFETV = VALOREFETV + @VALOR,
                              USUARIO = @USUARIO, DATAATU = GETDATE()
          WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
            AND NUMORIGEM = @NUMORIGEM

         SELECT @SQLERROR = @@error + 30000
         IF (@SQLERROR > 30000) 
            BEGIN
            SELECT @ERRO = 'Erro na alteracao da previsao'
            goto trata_erro
            END 
         END

      /* Subtrai do Valor de Previsoes Efetivadas */
      IF @TIPO_ALT = 4
         BEGIN
         UPDATE PREVISOES SET VALOREFETV = VALOREFETV - @VALOR,
                              USUARIO = @USUARIO, DATAATU = GETDATE()
          WHERE CODINST = @CODINST AND CODSISTEMA_O = @CODSISTEMA_O
            AND NUMORIGEM = @NUMORIGEM

         SELECT @SQLERROR = @@error + 30000
         IF (@SQLERROR > 30000) 
            BEGIN
            SELECT @ERRO = 'Erro na alteracao da previsao'
            goto trata_erro
            END 
         END

      IF @TEMTRANSACAO = 'S'
         COMMIT TRANSACTION
	return(0)

/* rotina de erro    */
trata_erro:
      IF @TEMTRANSACAO = 'S'
         ROLLBACK TRANSACTION
 	IF (@SQLERROR > 30000)
  	BEGIN
		SELECT @ERRO = @ERRO + ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na alteracao da tabela PREVISOES'
		return(1)
	END
end
go


/*
  $Id$
  Autbank Projetos e Consultoria Ltda.

  	Procedure SP_CANCELA_PREVISAO
	Data Criacao : 12/09/2001
	Autora : Carlos Augusto
	Descricao : Cancelamento de PREVISOES. 
      Alteracoes: 
                  17/05/2004 - Incluiu parametro @TEMTRANSACAO
*/

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_CANCELA_PREVISAO')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_CANCELA_PREVISAO  AS BEGIN RETURN END'  
END
go

ALTER PROC dbo.SP_CANCELA_PREVISAO (
	@CODSISTEMA_O char(10),
	@CODINST	  char(8),
	@NUMORIGEM	  char(20),
      @TEMTRANSACAO CHAR(01),
	@ERRO		varchar(50) output
)
as begin
	declare @SQLERROR int

      IF @TEMTRANSACAO = 'S'
         BEGIN TRANSACTION

  	select @ERRO = ''

	/* Verifica se o codigo da instituicao logada � valido*/
	IF NOT EXISTS(select CODINST from EMPRESAS where CODINST = @CODINST)
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Codigo da instituicao logada nao cadastrado'
         goto trata_erro
         END
	
      IF exists(SELECT * FROM PREVISOES 
                 WHERE CODSISTEMA_O = @CODSISTEMA_O
                   AND CODINST = @CODINST
                   AND NUMORIGEM = @NUMORIGEM
                   AND SITUACAO = 'C')
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Previsao ja cancelada'
         goto trata_erro
         END

      UPDATE PREVISOES SET SITUACAO = 'C'
       WHERE CODSISTEMA_O = @CODSISTEMA_O
         AND CODINST = @CODINST
         AND NUMORIGEM = @NUMORIGEM

	SELECT @SQLERROR = @@error + 30000
	IF (@SQLERROR > 30000) 
	BEGIN
		SELECT @ERRO = 'Erro na inclus�o da previs�o'
		goto trata_erro
	END 

      IF @TEMTRANSACAO = 'S'
         COMMIT TRANSACTION
	return(0)

/* rotina de erro    */
trata_erro:
      IF @TEMTRANSACAO = 'S'
         ROLLBACK TRANSACTION
 	IF (@SQLERROR > 30000)
  	BEGIN
		SELECT @ERRO = @ERRO + ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela PREVISOES'
		return(1)
	END
end
go

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_REGISTRA_DESTINO_MENSAGEM')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_REGISTRA_DESTINO_MENSAGEM  AS BEGIN RETURN END'  
END
go

ALTER PROC dbo.SP_REGISTRA_DESTINO_MENSAGEM (
   @NUMCTRLSPB   char(20),
   @CODINST      char(8),
   @DATAMOVTO    datetime,
   @DESTINO      char(10),
   @CODUSARIO    char(30),
   @ERRO         varchar(50) output
)
as
begin
   declare @SQLERROR int

   BEGIN TRANSACTION

   select @ERRO = ''

   insert into MENSAGENS_TRATADAS_DESTINO
      (NUMCTRLSPB,
       CODINST,
       DATAMOVTO,
       DESTINO,
       CODUSUARIO,
       DATAATU)
   values
      (@NUMCTRLSPB,
       @CODINST,
       @DATAMOVTO,
       @DESTINO,
       @CODUSARIO,
       getdate())

   select @SQLERROR = @@error
   if @SQLERROR != 0
      begin
         ROLLBACK TRANSACTION
         select @ERRO = ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na inser��o da tabela MENSAGENS_TRATADAS_DESTINO' 
         return(1)
      end

   COMMIT TRANSACTION
   return(0)

end
go

/*
  $Id$
  Autbank Projetos e Consultoria Ltda.

  	Procedure SP_INCLUI_OPERACAO
	Data Criacao : 06/01/2002
	Autor : Carlos Augusto
	Descricao : Inclusao de dados na tabela OPERACOES_LEGADOS. 
      Manutencoes: 
        04/02/2002  Inclusao do parametro DESCONPAR
        15/03/2002  Inclusao dos parametros TIPO_EMS, CNPJTITOPER e DESCOPER
        17/05/2004 - Incluiu parametro @TEMTRANSACAO
        20/12/2010 - Alterado o parametro @QTDNEGOC de numeric(12,2) para numeric(22,8)
*/

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_INCLUI_OPERACAO')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_INCLUI_OPERACAO  AS BEGIN RETURN END'  
END
go

ALTER PROC dbo.SP_INCLUI_OPERACAO (   
	@CODSISTEMA_O	char(10),
	@NUMORIGEM	      char(20),
	@CODINST	      char(8),
	@ISPBCAM		char(8),
	@OBJNEGOC		char(6),
	@QTDNEGOC		numeric(22,8),
	@DATAVENCTO 	datetime,
	@DATAMOVTO	      datetime,
	@DATARESERVA	datetime,
	@NATUREZAFIN	char(1),                 
	@NATUREZAQTD	char(1),                 
	@NUMOPCLRNG		char(15),
	@CNPJCONPAR 	char(14),	
	@DESCONPAR   	varchar(30),	
	@VALORMOVTO		numeric(17,2),
	@TIPO_LIQ	      char(03),
	@EMISSOROBJ 	char(15),	
	@NROBOLETO	      char(20),
      @TIPO_EMS         char(2),
      @CNPJTITOPER      char(14),
      @DESCOPER         varchar(30),
      @TEMTRANSACAO     CHAR(01),
	@ERRO		      varchar(50) output
)
as begin
	declare @SQLERROR int,
		@DATARESERVAP datetime,
		@DATAMOVTOP datetime, 
		@DATAVENCTOP datetime, 
            @ISPBCONPAR char(8),
            @VALORPREV numeric(17,2),
            @NUMORIGEM_PRV char(20),
		@SQLCOUNT int 

  	select  @ERRO = '',
		@DATARESERVAP = convert(datetime,(convert(char(10),@DATARESERVA,101) + ' ' + convert(char(5),@DATARESERVA,108))),
	      @DATAMOVTOP = convert(datetime,convert(char(10),@DATAMOVTO,101)),
	      @DATAVENCTOP = convert(datetime,convert(char(10),@DATAVENCTO,101)),
            @ISPBCONPAR = ''

      IF @TEMTRANSACAO = 'S'
         BEGIN TRANSACTION

	/* Verifica Nro Boleto*/
      IF @NROBOLETO is null OR @NROBOLETO = ''
         SELECT @NROBOLETO = @NUMORIGEM

	/* Verifica se o tipo de natureza e valido*/
	if (@NATUREZAFIN <> 'C' and @NATUREZAFIN <> 'D' and @NATUREZAFIN <> 'N')
    	begin
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'Tipo de natureza invalido'
		goto trata_erro
	end	

      IF RTRIM(@NATUREZAQTD) <> ''
         BEGIN 
         if (@NATUREZAQTD <> 'C' and @NATUREZAQTD <> 'D' and @NATUREZAQTD <> 'N')
             begin
		 SELECT @SQLERROR = @@error + 30000
		 SELECT @ERRO = 'Tipo de natureza invalido'
		 goto trata_erro
             end	
         END

	/* Verifica se o valor da operacao e maior que zero*/
	if (@VALORMOVTO <= 0)
    	begin
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'O valor da operacao deve ser maior que zero'
		goto trata_erro
	end	
	
	/* Verifica a quant de objeto negociada*/
	if (@QTDNEGOC <= 0)
    	begin
		SELECT @SQLERROR = @@error + 30000
		SELECT @ERRO = 'Quantidade de Objeto Negociado deve ser maior que zero'
		goto trata_erro
	end	

	/* Verifica se o codigo da instituicao logada e valido*/
	IF NOT EXISTS(select CODINST from EMPRESAS where CODINST = @CODINST)
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Codigo da instituicao logada nao cadastrado'
         goto trata_erro
         END
	
	/* Verifica se o CNPJ da instituicao da contraparte e valido*/
      IF RTRIM(@CNPJCONPAR) <> ''
         BEGIN
--         IF NOT EXISTS(select CODINST From INSTITUICOES where CNPJ = @CNPJCONPAR)
--            BEGIN
--            SELECT @SQLERROR = @@error + 30000
--            SELECT @ERRO = 'CNPJ da instituicao financeira - contraparte, nao cadastrado'
--            goto trata_erro
--            END
         select @ISPBCONPAR = ISNULL(CODINST, '') From INSTITUICOES where CNPJ = @CNPJCONPAR
         END

    	insert into OPERACOES_LEGADOS
	(
		CODSISTEMA_O,
		NUMORIGEM,
		CODINST,
		ISPBCAM,
		OBJNEGOC,
		QTDNEGOC,
		DATAVENCTO,
		DATAMOVTO,
		DATARESERVA,
		NATUREZAFIN,                 
		NATUREZAQTD,                 
		NUMOPCLRNG,                 
		CNPJCONPAR,
		DESCONPAR,
		ISPBCONPAR,
		VALORMOVTO,
            TIPO_LIQ,
		EMISSOROBJ,
		NROTRANSLIG,
		STATUS_OP,
		CONCILIADA,
		NROBOLETO,
            TIPO_EMS, 
            CNPJTITOPER,
            DESCOPER
	)
	values
	(
		@CODSISTEMA_O,
		@NUMORIGEM,
		@CODINST,
		@ISPBCAM,
		@OBJNEGOC,
		@QTDNEGOC,
		@DATAVENCTOP,
		@DATAMOVTOP,
		@DATARESERVAP,
		@NATUREZAFIN,                 
		@NATUREZAQTD,                 
		@NUMOPCLRNG,                 
		@CNPJCONPAR,
		@DESCONPAR,
		@ISPBCONPAR,
		@VALORMOVTO,
            @TIPO_LIQ,
            @EMISSOROBJ,
            null,
            '0',
            'N',
		@NROBOLETO,
            @TIPO_EMS,
            @CNPJTITOPER,
            @DESCOPER
	)

	SELECT @SQLERROR = @@error + 30000
	IF (@SQLERROR > 30000) 
	BEGIN
		SELECT @ERRO = 'Erro na inclusao da operacao'
		goto trata_erro
	END 

      IF EXISTS(SELECT VALORMOVTO
                  FROM PREVISOES
                 WHERE CODSISTEMA_O = @CODSISTEMA_O AND CODINST = @CODINST 
                   AND NROBOLETO = @NROBOLETO)
         BEGIN

         SELECT @VALORPREV = ISNULL(VALORMOVTO, 0)
           FROM PREVISOES
          WHERE CODSISTEMA_O = @CODSISTEMA_O AND CODINST = @CODINST AND NROBOLETO = @NROBOLETO

         SELECT @NUMORIGEM_PRV = @NUMORIGEM, 
                @VALORPREV = @VALORPREV - @VALORMOVTO
         IF @VALORPREV < 0
            SELECT @VALORPREV = 0

         UPDATE PREVISOES SET VALORMOVTO = @VALORPREV
          WHERE CODSISTEMA_O = @CODSISTEMA_O AND CODINST = @CODINST AND NROBOLETO = @NROBOLETO

         SELECT @SQLERROR = @@error + 30000
         IF (@SQLERROR > 30000) 
            BEGIN
            SELECT @ERRO = 'Erro ao atualizar a tabela PREVISOES'
            goto trata_erro
            END 

         INSERT INTO OPERACOES_CONC (
            CODSISTEMA_O,
            CODINST,
            NUMORIGEM_PRV,
            NUMORIGEM_OPE)
         VALUES (
            @CODSISTEMA_O,
            @CODINST,
            @NUMORIGEM_PRV,
            @NUMORIGEM)

         SELECT @SQLERROR = @@error + 30000
         IF (@SQLERROR > 30000) 
            BEGIN
            SELECT @ERRO = 'Erro ao gravar na tabela OPERACOES_CONC'
            goto trata_erro
            END 

         END

      IF @TEMTRANSACAO = 'S'
         COMMIT TRANSACTION

	return(0)

/* rotina de erro    */
trata_erro:
      IF @TEMTRANSACAO = 'S'
         ROLLBACK TRANSACTION
 	IF (@SQLERROR > 30000)
  	BEGIN
		SELECT @ERRO = @ERRO + ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na insercao da tabela OPERACOES_LEGADOS'
		return(1)
	END
end
go



/*
  $Id$
  Autbank Projetos e Consultoria Ltda.

  	Procedure SP_ALTERA_OPERACAO
	Data Criacao : 06/01/2002
	Autora : Carlos Augusto
	Descricao : Alteracao Status na tabela OPERACOES_LEGADOS. 
*/

IF NOT EXISTS (SELECT NAME FROM SYSOBJECTS WHERE name = 'SP_ALTERA_OPERACAO')
BEGIN
       EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE dbo.SP_ALTERA_OPERACAO  AS BEGIN RETURN END'  
END
go

ALTER PROC SP_ALTERA_OPERACAO (   
	@CODSISTEMA_O  char(10),
	@NUMORIGEM     char(20),
	@STATUS_OP	   char(1),
	@ERRO	         varchar(50) output
)
as begin
	declare @SQLERROR int

  	select  @ERRO = ''

      IF NOT EXISTS(SELECT * FROM OPERACOES_LEGADOS
                     WHERE CODSISTEMA_O = @CODSISTEMA_O AND NUMORIGEM = @NUMORIGEM)
         BEGIN
         SELECT @SQLERROR = @@error + 30000
         SELECT @ERRO = 'Operacao nao cadastrada.'
         goto trata_erro
         END

      UPDATE OPERACOES_LEGADOS SET STATUS_OP = @STATUS_OP
       WHERE CODSISTEMA_O = @CODSISTEMA_O AND NUMORIGEM = @NUMORIGEM

      SELECT @SQLERROR = @@error + 30000
      IF (@SQLERROR > 30000) 
         BEGIN
         SELECT @ERRO = 'Erro na alteracao da Operacao'
         goto trata_erro
         END 

	return(0)

/* rotina de erro    */
trata_erro:
 	IF (@SQLERROR > 30000)
  	BEGIN
		SELECT @ERRO = @ERRO + ' ERRO = ' + convert(char(10),@SQLERROR) + ' Erro na alteracao da tabela OPERACOES_LEGADOS'
		return(1)
	END
end
go

