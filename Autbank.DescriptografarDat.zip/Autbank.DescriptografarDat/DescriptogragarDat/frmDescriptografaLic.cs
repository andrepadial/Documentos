﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace DescriptogragarDat
{
    public partial class frmDescriptografaLic : Form
    {
        private static readonly byte[] Key = new byte[16]
        {
            244, 131, 177, 208, 112, 102, 115, 100, 52, 51,
            50, 49, 164, 36, 58, 198
        };

        private string KeyLic = "ôƒ±Ðpfsd4321¤$:Æ";

        public frmDescriptografaLic()
        {
            InitializeComponent();
        }

        private void frmDescriptografaLic_Load(object sender, EventArgs e)
        {
            
        }


        
    }
}
