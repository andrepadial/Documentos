﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DescriptogragarDat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            textBox1.Text = openFileDialog1.FileName.Replace("openFileDialog1", "");

            if (textBox1.Text.Length > 0)
            {
                //Credencial credencial = new Credencial();
                //credencial = Descriptografar.ObterCredencial(textBox1.Text, "SG");
                //textBox2.Text = credencial.UserName;
                //textBox3.Text = credencial.Password;

                List<Credencial> credenciais = new List<Credencial>();
                credenciais = Descriptografar.ObterCredenciais(textBox1.Text);
                dataGridView1.DataSource = credenciais;                
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
