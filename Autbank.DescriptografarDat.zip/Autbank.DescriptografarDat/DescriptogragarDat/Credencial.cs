﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DescriptogragarDat
{
    public class Credencial
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string CodSistema { get; set; }
    }
}
