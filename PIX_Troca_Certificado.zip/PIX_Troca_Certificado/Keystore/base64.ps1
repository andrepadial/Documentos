$FilePath = $args[0]
$File = [System.IO.File]::ReadAllBytes($FilePath);
[System.Convert]::ToBase64String($File) > $args[1]
